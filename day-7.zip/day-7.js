//nomor 1
//let tahunKabisat = 2021;

//if ((tahunKabisat % 4 === 0 && tahunKabisat % 100 !== 0) || (tahunKabisat % 400 === 0)) {
//    console.log(tahunKabisat + " adalah tahun kabisat.");
//} else {
//    console.log(tahunKabisat + " bukan tahun kabisat.");
//}

//nomor2
const hapusSimbol = (str) => {
    let result = "";

    for (let i = 0; i < str.length; i++) {
        const hapus = str[i];

        if ((hapus >= 'a' && hapus <= 'z') || (hapus >= 'A' && hapus <= 'Z') || (hapus >= '0' && hapus <= '9')) {
            result += hapus;
}
}

    return result;
};

const inputString = "Halo!! Apa kabar kalian? 123.";
const hapusString = hapusSimbol(inputString);
console.log("String setelah penghapusan simbol: " + hapusString);